branch = 'fix'
nightly = False
official = True
version = '8.2.3.24061702'
version_name = '64bit Sensation'
